var LocalStrategy = require('passport-local').Strategy;
var User = require('./user');

module.exports = function (passport) {
    passport.serializeUser(function (user, done) {
        done(null, user.id);
    });
    passport.deserializeUser(function (id, done) {
        User.findById(id, function(err, user) {
            done(err, user);
        });
    });
    passport.use('signup', new LocalStrategy({
        usernameField: 'username',
        passwordField: 'password',
        passReqToCallback: true
    }, function (req, username, password, done) {
        process.nextTick(function () {
            User.findOne({'username':username}, function (err, user) {
                if(err) {
                    return done(err);
                }
                if(user) {
                    return done(null, false, req.flash('signupMessage', 'Użytkownik o takim loginie już istnieje.'));
                } else {
                    var newUser = new User();
                    newUser.username = username;
                    newUser.password = newUser.hashPassword(password);
                    newUser.level = 'user';
                    newUser.save(function(err) {
                        if(err) {
                            throw err;
                        }
                        return done(null, newUser);
                    });
                }
            });
        });
    }));

    passport.use('login', new LocalStrategy({
        usernameField: 'username',
        passwordField: 'password',
        passReqToCallback: true
    }, function (req, username, password, done) {
        User.findOne({'username':username}, function (err, user) {
            if(err) {
                return done(err);
            }
            if(!user) {
                return done(null, false, req.flash('loginMessage', 'Użytkownik o takim loginie nie istnieje.'));
            }
            if(!user.checkPassword(password)) {
                return done(null, false, req.flash('loginMessage', 'Błędne hasło.'));
            }
            return done(null, user);
        });
    }));
};