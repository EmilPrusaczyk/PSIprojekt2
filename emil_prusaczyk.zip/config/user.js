var mongoose = require('mongoose');
var userSchema = mongoose.Schema({
    username:String,
    password:String,
    level:String
});
var bcrypt = require('bcrypt-nodejs');
userSchema.methods.hashPassword = function(password) {
    return bcrypt.hashSync(password, bcrypt.genSaltSync(8), null);
};
userSchema.methods.checkPassword = function(password) {
    return bcrypt.compareSync(password, this.password);
};
userSchema.methods.deleteUser = function () {
    this.remove();
};

module.exports = mongoose.model('User', userSchema);