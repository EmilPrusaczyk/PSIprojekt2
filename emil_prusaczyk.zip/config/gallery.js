var mongoose = require('mongoose');
var gallerySchema = mongoose.Schema({
    path:String,
    numComments:Number,
    comments: [{
        comment: String,
        username: String
    }]
});
gallerySchema.methods.addComment = function (username, text) {
    this.numComments++;
    this.comments.push({comment: text, username: username});
};
gallerySchema.methods.deletePicture = function () {
    this.remove();
};

module.exports = mongoose.model('Picture', gallerySchema);