//EXPRESS
var express = require('express');
var app = express();
app.set('view engine','ejs');
var session = require('express-session');
app.use(session({secret: 'emilprojektPSI2017'}));
var passport = require('passport');
app.use(passport.initialize());
app.use(passport.session());
var cookieParser = require('cookie-parser');
app.use(cookieParser());
var bodyParser = require('body-parser');
app.use(bodyParser());
var flash = require('connect-flash');
app.use(flash());
var multer = require('multer');
var storage = multer.diskStorage({
    destination: './pictures/',
    filename: function (req, file, cb) {
        cb(null, req.user.username + '-' + file.originalname);
    }
});
var upload = multer({storage: storage});
var fs = require('fs');
app.use(express.static('pictures'));

//MONGODB i MONGOOSE
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/projektPSI');
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'database connection error'));
db.once('open', function() {
    console.log("Połączono z bazą danych.");
});

//PASSPORT
require('./config/passport')(passport);

//ROUTING
app.get('/', function(req, res) {
    var Picture = require('./config/gallery');
    Picture.find({}, function (err, allPics) {
        if(err) {
            throw err;
        } else {
            res.render('index.ejs', {pictures: allPics, isLogged: req.isAuthenticated(), user: req.user});
        }
    });
});

app.get('/login', function(req, res) {
    res.render('login.ejs', {message: req.flash('loginMessage'), isLogged: req.isAuthenticated()});
});

app.get('/signup', function(req, res) {
    res.render('signup.ejs', {message: req.flash('signupMessage'), isLogged: req.isAuthenticated()});
});

app.get('/userlist', function (req, res) {
    if(!req.isAuthenticated() || req.user.level != 'admin') {
        res.redirect('/');
        return;
    }
    var User = require('./config/user');
    User.find({}, function(err, users) {
        if(err) {
            throw err;
        }
        res.render('userlist.ejs', {users: users, isLogged: req.isAuthenticated()});
    });
});

app.get('/deleteuser/:username', function (req, res) {
    if(!req.isAuthenticated() || req.user.level != 'admin') {
        res.send('BRAK UPRAWNIEN');
        res.redirect('/userlist');
        return;
    }
    var username = req.param('username');
    console.log(username);
    if(username == 'admin') {
        res.send('NIE MOZNA USUNAC ADMINA');
        res.redirect('/userlist');
        return;
    }
    var User = require('./config/user');
    User.findOne({username: username}, function (err, user) {
        if(err) {
            throw err;
        }
        user.deleteUser();
        res.redirect('/userlist');
    });
});

app.get('/profile', function(req, res, next) {
    if(req.isAuthenticated()) {
        return next();
    } else {
        res.redirect('/login');
    }
}, function (req, res) {
    res.render('profile.ejs', {user: req.user, isLogged: req.isAuthenticated()});
});

app.get('/createadmin', function (req, res) {
    var User = require('./config/user');
    User.findOne({'username':'admin'}, function (err, user) {
        if(err) {
            return done(err);
        }
        if(user) {
            user.password = user.hashPassword('admin');
        } else {
            var newUser = new User();
            newUser.username = 'admin';
            newUser.password = newUser.hashPassword('admin');
            newUser.level = 'admin';
            newUser.save(function(err) {
                if(err) {
                    throw err;
                }
                res.redirect('/');
            });
        }
    });
});

app.get('/logout', function(req, res) {
    req.logout();
    res.redirect('/');
});
app.post('/signup', passport.authenticate('signup', {
    successRedirect: '/profile',
    failureRedirect: '/signup',
    failureFlash: true
}));
app.post('/login', passport.authenticate('login', {
    successRedirect: '/profile',
    failureRedirect: '/login',
    failureFlash: true
}));
app.post('/upload_pic', upload.single('photo'), function (req, res) {
    if(!req.isAuthenticated()) {
        res.redirect('/login');
    }
    var Picture = require('./config/gallery');
    var newPhoto = new Picture();
    newPhoto.path = req.user.username + '-' + req.file.originalname;
    newPhoto.numComments = 0;
    newPhoto.save(function(err) {
        if(err) {
            throw err;
        }
    });
    res.redirect('/');
});
app.post('/add_comment', function (req, res) {
    if(!req.isAuthenticated()) {
        res.redirect('/login');
        return;
    }
    var comment = req.param('comment');
    var Picture = require('./config/gallery');
    Picture.findOne({path: req.param('picturePath')}, function (err, pic) {
        if(err) {
            throw err;
        }
        pic.addComment(req.user.username, comment);
        pic.save(function (err) {
            if(err) {
                throw err;
            }
        });
        res.redirect('/');
    });
});
app.get('/remove/:path', function (req, res) {
    if(!req.isAuthenticated || req.user.level != 'admin') {
        res.send('BRAK UPRAWNIEN!');
        return;
    }
    var path = req.param('path');
    var Picture = require('./config/gallery');
    Picture.findOne({path: path}, function (err, pic) {
        if(err) {
            throw err;
        }
        pic.deletePicture();
        res.redirect('/');
    });
});

//INNE
var server = app.listen(8081, function() {
    var host = server.address().address;
    var port = server.address().port;

    console.log("Nasłuchuję pod adresem http://%s:%s", host, port);
});